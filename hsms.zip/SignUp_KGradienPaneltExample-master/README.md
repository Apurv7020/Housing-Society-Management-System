# KGradientPanel Example

A KGradientPanel Sign Up example using Java Swing.
Clone - run and run with it.

![Example](https://github.com/k33ptoo/SignUp_KGradienPaneltExample/blob/master/images/Screenshot_26.png)


## Download KGradientPanel Jar
[KGradienPanel Jar](https://github.com/k33ptoo/KGradientPanel/raw/master/dist/KGradientPanel.jar)

Catch me outside.
* https://www.facebook.com/keeptoo.ui.ux/
* https://www.youtube.com/KeepToo
* https://t.me/byte2bits